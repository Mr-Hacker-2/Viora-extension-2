#!/usr/bin/env bash
# Viora — build a store-ready zip. No bundler; this only validates and packs.
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

version=$(grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' manifest.json | head -1 | cut -d'"' -f4)
out="dist/viora-extension-${version}.zip"

echo "Viora ${version}"

# 1. manifest must be valid JSON
if command -v python3 >/dev/null; then
  python3 -c "import json,sys; json.load(open('manifest.json'))" \
    && echo "  manifest: valid"
fi

# 2. every file the manifest points at must exist
missing=0
for path in \
  src/background/service-worker.js \
  src/sidepanel/index.html \
  src/options/options.html \
  src/content/content.js \
  src/content/content.css \
  icons/icon16.png icons/icon32.png icons/icon48.png icons/icon128.png
do
  [ -f "$path" ] || { echo "  missing: $path"; missing=1; }
done
[ "$missing" -eq 0 ] || { echo "Build stopped. Add the files above and run again."; exit 1; }
echo "  files: all present"

# 3. no key should ever be committed into source. dev-keys.js is for local
# testing only, is gitignored, and is deliberately excluded from this check
# and from the packed zip below — it must never ship.
if grep -rInE --exclude=dev-keys.js '(sk-[a-zA-Z0-9]{20,}|hf_[a-zA-Z0-9]{20,}|nvapi-[a-zA-Z0-9]{20,}|gsk_[a-zA-Z0-9]{20,})' src/ 2>/dev/null; then
  echo "  A live API key appears in src/ outside dev-keys.js. Remove it before packing."
  exit 1
fi
echo "  keys: none in shipped source"

# 4. pack
rm -rf dist
mkdir -p dist
zip -qr "$out" \
  manifest.json \
  src icons \
  README.md LICENSE \
  -x '*.DS_Store' '*/.*' 'src/lib/dev-keys.js'

echo "  wrote: $out ($(du -h "$out" | cut -f1))"
