#!/usr/bin/env bash
# Viora — commit the current build and push it to GitHub.
#
#   ./scripts/deploy.sh                 commit and push to main
#   ./scripts/deploy.sh --tag           also tag the manifest version and push it,
#                                       which triggers the release workflow
#
# Auth: set GITHUB_TOKEN, or have an SSH key or credential helper already
# configured. Nothing here prints or stores a token. src/lib/dev-keys.js is
# gitignored, so this never pushes a personal testing key.
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

tag_release=false
[ "${1:-}" = "--tag" ] && tag_release=true

version=$(grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' manifest.json | head -1 | cut -d'"' -f4)
branch="${GIT_BRANCH:-main}"

command -v git >/dev/null || { echo "git is not installed."; exit 1; }

./scripts/build.sh

if [ ! -d .git ]; then
  git init -q -b "$branch"
  echo "Initialised a repository on $branch."
fi

[ -n "${GIT_USER_NAME:-}" ] && git config user.name "$GIT_USER_NAME"
[ -n "${GIT_USER_EMAIL:-}" ] && git config user.email "$GIT_USER_EMAIL"

if ! git remote get-url origin >/dev/null 2>&1; then
  if [ -z "${GITHUB_REPO:-}" ]; then
    echo "No remote set. Export GITHUB_REPO=owner/name, then run again."
    exit 1
  fi
  if [ -n "${GITHUB_TOKEN:-}" ]; then
    git remote add origin "https://x-access-token:${GITHUB_TOKEN}@github.com/${GITHUB_REPO}.git"
  else
    git remote add origin "git@github.com:${GITHUB_REPO}.git"
  fi
  echo "Remote added for ${GITHUB_REPO}."
fi

git add -A
if git diff --cached --quiet; then
  echo "Nothing to commit."
else
  git commit -q -m "Viora ${version}

Chat, code and math, image generation, cited research, and page automation
in one Manifest V3 side panel."
  echo "Committed Viora ${version}."
fi

git push -u origin "$branch"
echo "Pushed to origin/${branch}."

if $tag_release; then
  if git rev-parse "v${version}" >/dev/null 2>&1; then
    echo "Tag v${version} already exists. Bump the manifest version to cut a new release."
  else
    git tag -a "v${version}" -m "Viora ${version}"
    git push origin "v${version}"
    echo "Tagged v${version}. The release workflow will attach the zip."
  fi
fi
