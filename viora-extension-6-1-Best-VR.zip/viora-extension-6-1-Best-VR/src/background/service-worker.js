/**
 * Viora — service worker.
 * Opens the panel, sets up context menus, and relays selected text.
 * Model calls run in the panel itself, where the stream can render directly.
 */

import { getSettings, saveSettings } from '../lib/storage.js';

const MENUS = [
  { id: 'viora-ask', title: 'Ask Viora about “%s”', contexts: ['selection'] },
  { id: 'viora-explain', title: 'Explain this code with Viora', contexts: ['selection'] },
  { id: 'viora-page', title: 'Summarise this page with Viora', contexts: ['page'] }
];

chrome.runtime.onInstalled.addListener(async (details) => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

  chrome.contextMenus.removeAll(() => {
    for (const menu of MENUS) chrome.contextMenus.create(menu);
  });

  // Touch storage once so defaults exist before the panel first reads them.
  await saveSettings({});

  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const task =
    info.menuItemId === 'viora-explain'
      ? { mode: 'code', prompt: `Explain this:\n\n${info.selectionText ?? ''}` }
      : info.menuItemId === 'viora-page'
        ? { mode: 'chat', prompt: 'Summarise the page I am reading.', usePage: true }
        : { mode: 'chat', prompt: info.selectionText ?? '' };

  await chrome.storage.session.set({ pendingTask: { ...task, tabId: tab?.id, at: Date.now() } });
  if (tab?.windowId != null) await chrome.sidePanel.open({ windowId: tab.windowId });
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'viora:get-task') {
    chrome.storage.session.get('pendingTask').then(({ pendingTask }) => {
      chrome.storage.session.remove('pendingTask');
      reply(pendingTask || null);
    });
    return true;
  }

  if (msg?.type === 'viora:settings') {
    getSettings().then(reply);
    return true;
  }

  return false;
});
