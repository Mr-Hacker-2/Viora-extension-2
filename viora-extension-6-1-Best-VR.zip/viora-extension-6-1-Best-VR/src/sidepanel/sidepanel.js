/**
 * Viora — side panel controller.
 * Owns the thread, routes each mode to its provider, and renders the stream.
 */

import { getSettings, saveSettings, getThreads, saveThread, deleteThread, newThread, missingKeysFor, textProviderFor } from '../lib/storage.js';
import { streamChat, completeChat, generateImage, searchWeb, listModels, ProviderError } from '../lib/providers.js';
import { renderMarkdown, bindCodeCopy, escapeHtml } from '../lib/markdown.js';
import { sourceStrip, linkInlineMarkers } from '../lib/citations.js';
import { SYSTEM, withPageContext, searchBlock } from '../lib/prompts.js';
import { activeTab, snapshot, pageContext, parsePlan, runPlan, describeAction } from '../lib/automation.js';

const $ = (sel) => document.querySelector(sel);

const el = {
  root: document.documentElement,
  thread: $('#thread'),
  welcome: $('#welcome'),
  suggestions: $('#suggestions'),
  form: $('#composer'),
  input: $('#input'),
  send: $('#send'),
  hint: $('#hint'),
  status: $('#status'),
  usePage: $('#use-page'),
  provider: $('#provider'),
  drawer: $('#drawer'),
  threadList: $('#thread-list'),
  threadEmpty: $('#thread-empty')
};

const SUGGESTIONS = {
  chat: ['Summarise what I am reading', 'Draft a reply to this email', 'Compare two options for me'],
  code: ['Why does this throw a null reference?', 'Write a debounce hook in TypeScript', 'Solve 3x² − 7x + 2 = 0 step by step'],
  image: ['A quiet reading room at dusk', 'Isometric city block, paper-cut style', 'Portrait lit by a single window'],
  research: ['What changed in EU AI rules this year?', 'Compare the latest flagship phone cameras', 'Who is hiring for WebGPU work?'],
  automate: ['Fill this form with my details', 'Find the pricing table and read it out', 'Open the first search result']
};

let settings = await getSettings();
let thread = newThread(settings.prefs.mode);
let controller = null;
let busy = false;

/* ---------------- shell ---------------- */

function setMode(mode) {
  thread.mode = mode;
  el.root.dataset.mode = mode;
  document.querySelectorAll('.mode').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.mode === mode)));
  el.input.placeholder = mode === 'image' ? 'Describe the image' : mode === 'automate' ? 'Tell Viora what to do on this page' : 'Ask anything';
  el.usePage.parentElement.hidden = mode === 'image' || mode === 'automate';
  el.provider.hidden = mode === 'image';
  renderSuggestions();
  renderProviderPicker();
  checkKeys();
  saveSettings({ prefs: { mode } });
}

function renderSuggestions() {
  el.suggestions.replaceChildren();
  for (const text of SUGGESTIONS[thread.mode] || []) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'suggestion';
    b.textContent = text;
    b.addEventListener('click', () => {
      el.input.value = text;
      el.input.focus();
      autosize();
    });
    el.suggestions.append(b);
  }
}

const TEXT_PROVIDERS = ['groq', 'deepseek'];

function renderProviderPicker() {
  const options = [{ value: 'auto', label: 'Auto' }];
  for (const name of TEXT_PROVIDERS) {
    const p = settings.providers[name];
    const state = p.apiKey ? (p.free ? ' · free' : '') : ' · no key';
    options.push({ value: name, label: `${p.label}${state}` });
  }

  el.provider.replaceChildren();
  for (const o of options) {
    const opt = document.createElement('option');
    opt.value = o.value;
    opt.textContent = o.label;
    el.provider.append(opt);
  }
  el.provider.value = settings.prefs.textProvider || 'auto';
  el.provider.title = `Answering with ${settings.providers[textProviderFor(settings)].label}`;
}

function checkKeys() {
  const missing = missingKeysFor(thread.mode, settings);
  if (missing.length) {
    const names = missing.map((m) => settings.providers[m].label).join(' and ');
    setStatus(`${names} needs an API key. Open settings to add one.`);
  } else {
    setStatus('');
  }
}

function setStatus(text) {
  el.status.textContent = text;
  el.status.hidden = !text;
}

function setBusy(state) {
  busy = state;
  el.send.classList.toggle('stop', state);
  el.send.setAttribute('aria-label', state ? 'Stop' : 'Send');
  el.hint.textContent = state ? 'Streaming' : '';
}

function scrollDown() {
  el.thread.scrollTop = el.thread.scrollHeight;
}

function autosize() {
  el.input.style.height = 'auto';
  el.input.style.height = `${Math.min(el.input.scrollHeight, 168)}px`;
}

/* ---------------- rendering ---------------- */

function clearWelcome() {
  if (el.welcome.isConnected) el.welcome.remove();
}

function addUser(text) {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg user';
  node.textContent = text;
  el.thread.append(node);
  scrollDown();
}

function addAssistant() {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant streaming';

  const trace = document.createElement('details');
  trace.className = 'reasoning';
  trace.hidden = true;
  const summary = document.createElement('summary');
  summary.textContent = 'Reasoning';
  const pre = document.createElement('div');
  pre.className = 'trace';
  trace.append(summary, pre);

  const body = document.createElement('div');
  body.className = 'body';

  node.append(trace, body);
  el.thread.append(node);
  scrollDown();

  return {
    node,
    body,
    trace,
    tracePre: pre,
    setReasoning(text) {
      if (!settings.prefs.showReasoning || !text) return;
      trace.hidden = false;
      pre.textContent = text;
    },
    setMarkdown(text) {
      body.innerHTML = renderMarkdown(text);
    },
    finish() {
      node.classList.remove('streaming');
      bindCodeCopy(body);
    }
  };
}

function addError(err, retry, extra) {
  clearWelcome();
  const box = document.createElement('div');
  box.className = 'msg assistant';
  const inner = document.createElement('div');
  inner.className = 'error';
  inner.textContent = err.message || 'Something went wrong.';
  if (err.hint) {
    const fix = document.createElement('span');
    fix.className = 'fix';
    fix.textContent = err.hint;
    inner.append(fix);
  }
  if (retry) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Try again';
    btn.addEventListener('click', () => {
      box.remove();
      retry();
    });
    inner.append(btn);
  }
  box.append(inner);
  if (extra) inner.append(extra);
  el.thread.append(box);
  scrollDown();
}

/**
 * When a model name has been retired, ask the provider what it does serve and
 * let the user switch with one click rather than hunting through settings.
 */
function modelPicker(providerName, retryFn) {
  const wrap = document.createElement('div');
  wrap.className = 'model-fix';

  const load = document.createElement('button');
  load.type = 'button';
  load.textContent = 'Show available models';

  load.addEventListener('click', async () => {
    load.disabled = true;
    load.textContent = 'Loading';
    try {
      const models = await listModels({ config: settings.providers[providerName] });
      load.remove();

      const note = document.createElement('p');
      note.className = 'fix';
      note.textContent = `${settings.providers[providerName].label} is serving ${models.length} models. Pick one to use from now on.`;

      const list = document.createElement('div');
      list.className = 'model-list';

      for (const id of models) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = id;
        b.addEventListener('click', async () => {
          settings = await saveSettings({
            providers: { [providerName]: { chatModel: id, reasonModel: id } }
          });
          renderProviderPicker();
          checkKeys();
          retryFn?.();
        });
        list.append(b);
      }

      wrap.append(note, list);
    } catch (err) {
      load.disabled = false;
      load.textContent = 'Show available models';
      const fail = document.createElement('span');
      fail.className = 'fix';
      fail.textContent = err.message;
      wrap.append(fail);
    }
  });

  wrap.append(load);
  return wrap;
}

/* ---------------- history ---------------- */

async function refreshDrawer() {
  const threads = await getThreads();
  el.threadList.replaceChildren();
  el.threadEmpty.hidden = threads.length > 0;

  for (const t of threads) {
    const li = document.createElement('li');
    const row = document.createElement('div');
    row.className = 'thread-item';

    const open = document.createElement('button');
    open.type = 'button';
    open.className = 't-title';
    open.textContent = t.title;
    open.style.cssText = 'border:none;background:none;text-align:left;cursor:pointer;color:inherit;';
    open.addEventListener('click', () => loadThread(t));

    const mode = document.createElement('span');
    mode.className = 't-mode';
    mode.textContent = t.mode;

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 't-del';
    del.title = 'Delete';
    del.textContent = '×';
    del.addEventListener('click', async () => {
      await deleteThread(t.id);
      refreshDrawer();
    });

    row.append(open, mode, del);
    li.append(row);
    el.threadList.append(li);
  }
}

function loadThread(saved) {
  thread = structuredClone(saved);
  el.drawer.hidden = true;
  el.thread.replaceChildren();
  setMode(thread.mode);

  for (const m of thread.messages) {
    if (m.role === 'user') {
      addUser(m.content);
    } else if (m.image) {
      renderImage(m.image);
    } else {
      const view = addAssistant();
      view.setReasoning(m.reasoning);
      view.setMarkdown(m.content);
      if (m.sources?.length) {
        linkInlineMarkers(view.body, m.sources);
        view.body.append(sourceStrip(m.sources));
      }
      view.finish();
    }
  }
  scrollDown();
}

async function persist(firstPrompt) {
  if (thread.title === 'New conversation' && firstPrompt) {
    thread.title = firstPrompt.replace(/\s+/g, ' ').slice(0, 52) + (firstPrompt.length > 52 ? '…' : '');
  }
  await saveThread(thread);
  refreshDrawer();
}

/* ---------------- modes ---------------- */

async function collectPage() {
  if (!el.usePage.checked) return null;
  const tab = await activeTab();
  if (!tab?.id) return null;
  try {
    return await pageContext(tab.id);
  } catch {
    setStatus('Viora cannot read this page. Chrome blocks extensions on its own pages.');
    return null;
  }
}

/** The text provider in use right now, with its config and model choice. */
function textRoute(preferReasoning = false) {
  const name = textProviderFor(settings);
  const config = settings.providers[name];
  const model = preferReasoning ? config.reasonModel || config.chatModel : config.chatModel;
  return { name, config, model };
}

async function runTextMode(prompt) {
  const page = await collectPage();
  const isCode = thread.mode === 'code';
  const { name, config: cfg, model } = textRoute(isCode);

  const messages = [
    { role: 'system', content: withPageContext(SYSTEM[thread.mode], page) },
    ...thread.messages.filter((m) => !m.image).map(({ role, content }) => ({ role, content })),
    { role: 'user', content: prompt }
  ];

  const view = addAssistant();
  let content = '';
  let reasoning = '';

  // Hosted R1-distill models put their chain inline in <think> tags rather
  // than in a separate field, so split it back out before rendering.
  const split = (raw) => {
    const open = raw.indexOf('<think>');
    if (open < 0) return { think: '', answer: raw };
    const close = raw.indexOf('</think>');
    return close < 0
      ? { think: raw.slice(open + 7), answer: '' }
      : { think: raw.slice(open + 7, close), answer: raw.slice(0, open) + raw.slice(close + 8) };
  };

  const result = await streamChat({
    provider: name,
    config: cfg,
    model,
    messages,
    temperature: isCode ? 0.2 : settings.prefs.temperature,
    maxTokens: settings.prefs.maxTokens,
    signal: controller.signal,
    onDelta: (d) => {
      if (d.reasoning) {
        reasoning += d.reasoning;
        view.setReasoning(reasoning);
      }
      if (d.content) {
        content += d.content;
        const { think, answer } = split(content);
        if (think) view.setReasoning(reasoning + think);
        view.setMarkdown(answer);
      }
      scrollDown();
    }
  });

  view.finish();
  const { think, answer } = split(result.content);
  thread.messages.push({
    role: 'assistant',
    content: answer.trim(),
    reasoning: (result.reasoning || think).trim()
  });
}

async function runResearch(prompt) {
  setStatus('Searching');
  const results = await searchWeb({
    config: settings.providers.search,
    query: prompt,
    signal: controller.signal
  });
  setStatus(results.length ? `Reading ${results.length} results` : 'No results found');

  const view = addAssistant();
  const messages = [
    { role: 'system', content: SYSTEM.research },
    { role: 'user', content: `Question: ${prompt}\n\nResults:\n${searchBlock(results)}` }
  ];

  const route = textRoute();
  let content = '';
  await streamChat({
    provider: route.name,
    config: route.config,
    model: route.model,
    messages,
    temperature: 0.3,
    maxTokens: settings.prefs.maxTokens,
    signal: controller.signal,
    onDelta: (d) => {
      content += d.content;
      view.setMarkdown(content);
      scrollDown();
    }
  });

  if (settings.prefs.citations && results.length) {
    linkInlineMarkers(view.body, results);
    view.body.append(sourceStrip(results));
  }
  view.finish();
  setStatus('');
  thread.messages.push({ role: 'assistant', content, sources: results });
}

function renderImage(image) {
  clearWelcome();
  const node = document.createElement('div');
  node.className = 'msg assistant';

  const img = document.createElement('img');
  img.className = 'gen-image';
  img.src = image.dataUrl;
  img.alt = image.prompt;
  img.loading = 'lazy';

  const meta = document.createElement('div');
  meta.className = 'image-meta';

  const name = document.createElement('span');
  name.textContent = image.model.split('/').pop();

  const save = document.createElement('a');
  save.textContent = 'Save';
  save.href = image.dataUrl;
  save.download = `viora-${Date.now()}.png`;

  const copyPrompt = document.createElement('button');
  copyPrompt.type = 'button';
  copyPrompt.textContent = 'Copy prompt';
  copyPrompt.addEventListener('click', async () => {
    await navigator.clipboard.writeText(image.prompt);
    copyPrompt.textContent = 'Copied';
    setTimeout(() => (copyPrompt.textContent = 'Copy prompt'), 1400);
  });

  meta.append(name, save, copyPrompt);
  node.append(img, meta);
  el.thread.append(node);
  scrollDown();
}

async function runImage(prompt) {
  let finalPrompt = prompt;

  // If DeepSeek is configured, let it expand a terse request into a full prompt.
  const writer = textRoute();
  if (writer.config.apiKey && prompt.split(/\s+/).length < 12) {
    setStatus('Writing the prompt');
    try {
      finalPrompt = (
        await completeChat({
          provider: writer.name,
          config: writer.config,
          model: writer.model,
          messages: [
            { role: 'system', content: SYSTEM.image },
            { role: 'user', content: prompt }
          ],
          signal: controller.signal
        })
      ).trim() || prompt;
    } catch {
      finalPrompt = prompt;
    }
  }

  setStatus('Generating image');
  const image = await generateImage({
    config: settings.providers.flux,
    prompt: finalPrompt,
    quality: prompt.length > 120 ? 'quality' : 'fast',
    signal: controller.signal
  });
  setStatus('');
  renderImage(image);
  thread.messages.push({ role: 'assistant', content: finalPrompt, image });
}

async function runAutomation(prompt) {
  const tab = await activeTab();
  if (!tab?.id) throw new ProviderError('No active tab to work with.');

  setStatus('Reading the page');
  const snap = await snapshot(tab.id);
  const elements = snap.elements.map((e) => `${e.ref}. <${e.tag}${e.type ? ` ${e.type}` : ''}> ${e.label}`).join('\n');

  // Nemotron plans when configured; otherwise the free text provider does.
  const planner = settings.providers.nemotron.apiKey
    ? { name: 'nemotron', config: settings.providers.nemotron, model: settings.providers.nemotron.chatModel }
    : textRoute();

  setStatus(`Planning with ${planner.config.label}`);
  const raw = await completeChat({
    provider: planner.name,
    config: planner.config,
    model: planner.model,
    messages: [
      { role: 'system', content: SYSTEM.automate },
      { role: 'user', content: `Task: ${prompt}\n\nPage: ${snap.title}\n${snap.url}\n\nElements:\n${elements}` }
    ],
    maxTokens: 700,
    signal: controller.signal
  });

  const plan = parsePlan(raw);
  clearWelcome();

  const node = document.createElement('div');
  node.className = 'msg assistant';
  const list = document.createElement('div');
  list.className = 'plan';
  node.append(list);

  if (plan.thought) {
    const body = document.createElement('div');
    body.className = 'body';
    body.innerHTML = `<p>${escapeHtml(plan.thought)}</p>`;
    node.prepend(body);
  }

  const rows = plan.actions.map((action) => {
    const row = document.createElement('div');
    row.className = 'step';
    row.dataset.state = 'idle';
    const dot = document.createElement('span');
    dot.className = 'dot';
    const label = document.createElement('span');
    label.textContent = describeAction(action);
    const detail = document.createElement('span');
    detail.className = 'detail';
    row.append(dot, label, detail);
    list.append(row);
    return { row, detail };
  });

  el.thread.append(node);
  scrollDown();

  setStatus('Running');
  let i = 0;
  await runPlan(tab.id, plan, (step) => {
    const ui = rows[i++];
    if (!ui) return;
    ui.row.dataset.state = step.ok ? 'ok' : 'fail';
    ui.detail.textContent = (step.detail || '').slice(0, 120);
    scrollDown();
  });
  setStatus('');

  thread.messages.push({
    role: 'assistant',
    content: `${plan.thought}\n\n${plan.actions.map(describeAction).map((s) => `- ${s}`).join('\n')}`
  });
}

/* ---------------- send ---------------- */

async function send(prompt) {
  if (busy || !prompt.trim()) return;

  const missing = missingKeysFor(thread.mode, settings);
  if (missing.length) {
    addError(
      new ProviderError(`${missing.map((m) => settings.providers[m].label).join(' and ')} needs an API key.`, {
        hint: 'Open settings from the top bar to add one.'
      })
    );
    return;
  }

  addUser(prompt);
  thread.messages.push({ role: 'user', content: prompt });
  el.input.value = '';
  autosize();

  controller = new AbortController();
  setBusy(true);

  try {
    if (thread.mode === 'image') await runImage(prompt);
    else if (thread.mode === 'research') await runResearch(prompt);
    else if (thread.mode === 'automate') await runAutomation(prompt);
    else await runTextMode(prompt);
    await persist(prompt);
  } catch (err) {
    document.querySelector('.msg.assistant.streaming')?.classList.remove('streaming');
    setStatus('');
    if (err.name === 'AbortError') {
      setStatus('Stopped');
    } else if (err.code === 'model_retired') {
      const provider = textProviderFor(settings);
      const retry = () => {
        document.querySelectorAll('.msg.assistant .error').forEach((n) => n.closest('.msg')?.remove());
        // The prompt is still the last user message, so drop it before resending.
        if (thread.messages.at(-1)?.role === 'user') thread.messages.pop();
        el.thread.querySelector('.msg.user:last-of-type')?.remove();
        send(prompt);
      };
      addError(err, null, modelPicker(provider, retry));
    } else {
      addError(err, () => send(prompt));
    }
  } finally {
    setBusy(false);
    controller = null;
  }
}

/* ---------------- events ---------------- */

el.form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (busy) {
    controller?.abort();
    return;
  }
  send(el.input.value);
});

el.input.addEventListener('input', autosize);

el.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    el.form.requestSubmit();
  }
});

el.provider.addEventListener('change', async () => {
  settings = await saveSettings({ prefs: { textProvider: el.provider.value } });
  renderProviderPicker();
  checkKeys();
});

document.querySelectorAll('.mode').forEach((b) => {
  b.addEventListener('click', () => setMode(b.dataset.mode));
});

$('#new-thread').addEventListener('click', () => {
  controller?.abort();
  thread = newThread(thread.mode);
  el.thread.replaceChildren(el.welcome);
  renderSuggestions();
  el.input.focus();
});

$('#history').addEventListener('click', (e) => {
  const open = el.drawer.hidden;
  el.drawer.hidden = !open;
  e.currentTarget.setAttribute('aria-expanded', String(open));
  if (open) refreshDrawer();
});

$('#open-settings').addEventListener('click', () => chrome.runtime.openOptionsPage());

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === 'local' && changes.settings) {
    settings = await getSettings();
    renderProviderPicker();
    checkKeys();
  }
});

/* ---------------- boot ---------------- */

setMode(settings.prefs.mode || 'chat');
refreshDrawer();
el.input.focus();

// Pick up anything queued from a context-menu click.
const task = await chrome.runtime.sendMessage({ type: 'viora:get-task' }).catch(() => null);
if (task?.prompt) {
  setMode(task.mode || 'chat');
  el.usePage.checked = Boolean(task.usePage);
  send(task.prompt);
}
