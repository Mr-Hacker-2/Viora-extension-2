import { getSettings, saveSettings, DEFAULTS } from '../lib/storage.js';
import { listModels } from '../lib/providers.js';

const fields = [...document.querySelectorAll('[data-path]')];
const result = document.getElementById('result');

const read = (obj, path) => path.split('.').reduce((o, k) => o?.[k], obj);

function write(obj, path, value) {
  const keys = path.split('.');
  const last = keys.pop();
  const target = keys.reduce((o, k) => (o[k] ??= {}), obj);
  target[last] = value;
}

function fill(settings) {
  for (const field of fields) {
    const path = field.dataset.path;

    if (field.type === 'checkbox') {
      field.checked = Boolean(read(settings, path));
      continue;
    }

    // An apiKey field whose value came from src/lib/dev-keys.js (not typed
    // here) stays blank — the raw key never gets written into this page's
    // DOM, even masked. A description explains what's active instead.
    if (path.endsWith('.apiKey') && read(settings, path.replace(/\.apiKey$/, '.fromDevFile'))) {
      field.value = '';
      field.placeholder = 'Using the local testing key — leave blank to keep it';
      continue;
    }

    field.value = read(settings, path) ?? '';
  }
}

function collect() {
  const patch = {};
  for (const field of fields) {
    const value =
      field.type === 'checkbox'
        ? field.checked
        : field.type === 'number'
          ? Number(field.value)
          : field.value.trim();
    write(patch, field.dataset.path, value);
  }
  return patch;
}

function say(text) {
  result.textContent = text;
}

document.getElementById('save').addEventListener('click', async () => {
  await saveSettings(collect());
  say('Saved.');
  setTimeout(() => say(''), 2200);
});

document.getElementById('reset').addEventListener('click', async () => {
  await chrome.storage.local.set({ settings: DEFAULTS });
  fill(DEFAULTS);
  say('Reset to defaults. Keys cleared.');
});

document.getElementById('test').addEventListener('click', async () => {
  await saveSettings(collect());
  const settings = await getSettings();
  say('Testing…');

  const checks = [
    ['Groq', settings.providers.groq, settings.providers.groq.chatModel],
    ['DeepSeek', settings.providers.deepseek, settings.providers.deepseek.chatModel],
    ['Nemotron', settings.providers.nemotron, settings.providers.nemotron.chatModel]
  ];

  const lines = [];
  for (const [name, config, model] of checks) {
    if (!config.apiKey) {
      lines.push(`${name}: no key`);
      continue;
    }
    try {
      const res = await fetch(`${config.baseUrl.replace(/\/$/, '')}/chat/completions`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1 })
      });
      lines.push(`${name}: ${res.ok ? 'connected' : `failed (${res.status})`}`);
    } catch {
      lines.push(`${name}: unreachable`);
    }
  }

  const flux = settings.providers.flux;
  lines.push(`FLUX: ${flux.apiKey ? 'key set' : 'no key'}`);
  lines.push(`Search: ${settings.providers.search.apiKey ? 'key set' : 'no key'}`);
  say(lines.join(' · '));
});

// Fill the model fields from the provider's live catalogue.
document.querySelectorAll('[data-load-models]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const name = btn.dataset.loadModels;
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Loading';
    try {
      await saveSettings(collect());
      const settings = await getSettings();
      const models = await listModels({ config: settings.providers[name] });
      const list = document.getElementById(btn.dataset.list);
      list.replaceChildren();
      for (const id of models) {
        const opt = document.createElement('option');
        opt.value = id;
        list.append(opt);
      }
      btn.textContent = `${models.length} models loaded`;
      say(`${name}: click a model field to choose from the live list.`);
    } catch (err) {
      btn.textContent = original;
      say(`${name}: ${err.message}`);
    } finally {
      btn.disabled = false;
    }
  });
});

fill(await getSettings());
