# Viora

A Chrome side panel that puts chat, code and maths, image generation, cited research, and page automation behind one interface.

Version 6.1.0 · Manifest V3 · no build step, no bundler, no dependencies.

## Install

1. Open `chrome://extensions` and turn on developer mode.
2. Choose **Load unpacked** and select this folder.
3. The settings page opens on first install. Add at least one API key, or see "Running for free" below.
4. Click the Viora icon, or press `Ctrl+Shift+Y` (`⌘+Shift+Y` on macOS).

## Attaching files

Chat and Code & math modes have an attach button (paperclip, next to the model picker) that takes images (PNG/JPEG/WebP/GIF), PDFs, and plain text (.txt/.md/.csv/.log). Up to 5 files per message.

- **Images** are downscaled client-side (1568px longest side, re-encoded as JPEG) and sent as inline data URLs to a vision-capable model — Groq's `qwen/qwen3.6-27b` by default, or whatever provider's `visionModel` is set if the active one has one. Without a vision-capable provider configured, Viora says so rather than silently sending text-only.
- **PDFs and text files** are read to plain text and folded into your message as a labelled block, since the chat APIs here have no separate file-upload endpoint.

### About the PDF reader

There's no bundler in this project and Chrome extension pages can't load a script from a CDN, so a library like pdf.js isn't an option. Instead `src/lib/files.js` ships a small extractor written for this extension: it decodes FlateDecode and ASCII85-wrapped content streams with the browser's native `DecompressionStream`, then reads text out of `Tj`/`TJ` show-text operators. That covers most text-based PDFs — word-processor exports, reportlab, LaTeX with simple fonts.

It will not do well with a scanned page (there's no OCR here) or a PDF built on composite CID-keyed fonts with two-byte glyph codes, which some professionally typeset documents use. Rather than return silently garbled text in that case, a sparse result carries a warning that surfaces as a chip tooltip and a status message — try exporting to .txt instead, or attach a screenshot as an image.

## Modes

| Mode | What it does | Needs |
| --- | --- | --- |
| Chat | General questions, drafting, summarising the page you are reading, file attachments | a text provider |
| Code & math | Writes and debugs code, explains algorithms, works through maths, file attachments | a text provider |
| Image | Turns a short request into a full prompt, then generates it | FLUX.1 |
| Research | Searches, then answers with numbered citations and source favicons | a text provider + a search key |
| Automate | Reads the page, plans up to five steps, runs them and shows the result | Nemotron, or the text provider |

**Text provider** means Groq or DeepSeek. The picker sits in the composer; Auto uses the free provider when it has a key, DeepSeek otherwise. Choosing a provider explicitly keeps it selected even without a key, so the panel tells you what is missing rather than quietly answering with something else.

Switching modes changes the accent colour of the panel, so the current mode is visible without reading a label.

## Automate mode and restricted pages

Chrome does not let any extension read or script into its own internal pages — `chrome://extensions`, `chrome://newtab`, the Web Store, and similar. This is a browser platform rule, not something a manifest permission can lift. If the active tab is one of these when you send a message in Automate mode, or with "Use this page" checked, Viora now says so directly and asks you to switch to a regular website tab, rather than surfacing Chrome's raw scripting error.

## Keys

Keys live in `chrome.storage.local`. They are not synced to a Google account and are sent only to the base URL configured for that provider. Settings has a **Test connections** button that sends a one-token request to confirm each key works.

Default endpoints:

- Groq — `https://api.groq.com/openai/v1` (free tier)
- DeepSeek — `https://api.deepseek.com/v1`
- NVIDIA Nemotron — `https://integrate.api.nvidia.com/v1`
- FLUX.1 — `https://router.huggingface.co/hf-inference/models`
- Search — `https://api.tavily.com`

Any OpenAI-compatible endpoint works in the text-provider fields, including a local server on `http://localhost`.

### Running for free

Groq's free tier covers chat, code, research and automation planning. Only image generation needs a separate key, since FLUX runs elsewhere.

`src/lib/dev-keys.js` can hold a key for local testing:

```js
export const DEV_KEYS = { groq: 'gsk_…' };
```

This file is gitignored, excluded from `scripts/build.sh`, and never written into `chrome.storage.local` — a key typed on the settings page always wins over it. **It is a personal convenience for your own machine, not a way to distribute a shared key.** If you package and hand this extension to someone else, `dev-keys.js` does not travel with it — they will see no key at all and need to add their own. Do not paste a shared or production key into this file, since anyone who reads the unpacked source (or your own git history if you remove it from `.gitignore`) can read it back out in plain text — nothing here obfuscates or protects it.

Delete the file, or empty the string, to make Viora key-less again.

### Model names go stale

Groq retires models several times a year — `llama-3.3-70b-versatile` and `llama-3.1-8b-instant` were deprecated in June 2026 and shut off that August. Viora ships `openai/gpt-oss-120b` as the default, but treat any hardcoded name as a guess.

Two ways to get the real list, both reading `GET /models` from the provider itself:

- In the panel, a retired model produces an error with a **Show available models** button. Click a model and the request is resent with it.
- On the settings page, **Load available models** fills the model fields with the live catalogue.

## How citations work

Research mode sends search results to the model with numbered labels and asks for `[n]` markers. After rendering, Viora replaces each marker with a small favicon link and appends a source strip under the answer.

Favicons come from Chrome's own cache via the `favicon` permission (`/_favicon/?pageUrl=…`), so no third-party tracking pixel is requested for every source a user sees. When Chrome has no icon cached, the chip falls back to a monogram tile with a hue derived from the domain.

## How automation works

The model never touches the DOM. The content script builds a numbered list of visible interactive elements; the planner returns JSON; `parsePlan` drops anything that is not one of `click`, `fill`, `scroll`, `extract`, `done` and caps the run at five steps. Every element Viora acts on gets a short violet outline so nothing happens invisibly. Before any of this runs, Viora checks whether the active tab is a page Chrome allows extensions to touch at all — see "Automate mode and restricted pages" above.

## Layout

```
manifest.json
src/
  background/service-worker.js   panel wiring, context menus
  content/content.js             page snapshot and action execution
  lib/
    providers.js                 streaming chat, image, search, model-list adapters
    storage.js                   settings, provider routing, saved conversations
    markdown.js                  small escape-first renderer
    citations.js                 favicon chips and inline markers
    automation.js                plan validation, dispatch, restricted-page checks
    files.js                     image/PDF/text attachment reading, the PDF extractor
    prompts.js                   one system prompt per mode
    dev-keys.js                  your local testing key (gitignored, not packed)
  sidepanel/                     the panel itself
  options/                       settings page
icons/
scripts/                         build and deploy
```

## Build and release

```bash
./scripts/build.sh          # writes dist/viora-extension-6.1.0.zip
./scripts/deploy.sh         # commits, tags, and pushes to GitHub
```

`deploy.sh` reads `GITHUB_REPO` from the environment or from `git remote origin`. Pushing a `v*` tag triggers `.github/workflows/release.yml`, which validates the manifest, builds the zip, and attaches it to a GitHub release. `dev-keys.js` is gitignored, so it is never committed or pushed.

## Known limits

- Chrome blocks content scripts and automation on `chrome://` pages, the Web Store, and similar — see "Automate mode and restricted pages" above.
- The bundled PDF reader handles typical text PDFs but not scanned pages or composite CID-font documents — see "About the PDF reader" above.
- Maths is styled, not typeset. Adding KaTeX would mean bundling it, which this build deliberately avoids.
- Free-tier reasoning models return their chain inside `<think>` tags rather than a separate field. Viora splits it back out, but a model that leaves the tag unclosed will show an empty answer until the stream finishes.
- The panel keeps the last 50 conversations locally and trims older ones.

## Licence

MIT. See `LICENSE`.
