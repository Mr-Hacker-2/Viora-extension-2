# Viora

A Chrome side panel that puts chat, code and maths, image generation, cited research, and page automation behind one interface.

Version 6.1.0 · Manifest V3 · no build step, no bundler, no dependencies.

## Install

1. Open `chrome://extensions` and turn on developer mode.
2. Choose **Load unpacked** and select this folder.
3. The settings page opens on first install. Add at least one API key.
4. Click the Viora icon, or press `Ctrl+Shift+Y` (`⌘+Shift+Y` on macOS).

## Modes

| Mode | What it does | Needs |
| --- | --- | --- |
| Chat | General questions, drafting, summarising the page you are reading | a text provider |
| Code & math | Writes and debugs code, explains algorithms, works through maths | a text provider |
| Image | Turns a short request into a full prompt, then generates it | FLUX.1 |
| Research | Searches, then answers with numbered citations and source favicons | a text provider + a search key |
| Automate | Reads the page, plans up to five steps, runs them and shows the result | Nemotron, or the text provider |

**Text provider** means Groq or DeepSeek. The picker sits in the composer; Auto uses the free provider when it has a key, DeepSeek otherwise. Choosing a provider explicitly keeps it selected even without a key, so the panel tells you what is missing rather than quietly answering with something else.

Switching modes changes the accent colour of the panel, so the current mode is visible without reading a label.

## Keys

Keys live in `chrome.storage.local`. They are not synced to a Google account and are sent only to the base URL configured for that provider. Settings has a **Test connections** button that sends a one-token request to confirm each key works.

Default endpoints:

- Groq — `https://api.groq.com/openai/v1` (free tier)
- DeepSeek — `https://api.deepseek.com/v1`
- NVIDIA Nemotron — `https://integrate.api.nvidia.com/v1`
- FLUX.1 — `https://router.huggingface.co/hf-inference/models`
- Search — `https://api.tavily.com`

Any OpenAI-compatible endpoint works in the text-provider fields, including a local server on `http://localhost`.

### Running for free

Groq's free tier covers chat, code, research and automation planning. Only image generation needs a separate key, since FLUX runs elsewhere.

`src/lib/dev-keys.js` can hold a key for local testing. It is gitignored, excluded from `build.sh`, and never written into `chrome.storage.local` — a key typed on the settings page always wins over it. Delete the file to make Viora key-less again. Free tiers are rate limited, so a long session may pause with a 429; the panel says so and offers a retry.

### Model names go stale

Groq retires models several times a year — `llama-3.3-70b-versatile` and `llama-3.1-8b-instant` were deprecated in June 2026 and shut off that August. Viora ships `openai/gpt-oss-120b` as the default, but treat any hardcoded name as a guess.

Two ways to get the real list, both reading `GET /models` from the provider itself:

- In the panel, a retired model produces an error with a **Show available models** button. Click a model and the request is resent with it.
- On the settings page, **Load available models** fills the model fields with the live catalogue.

## How citations work

Research mode sends search results to the model with numbered labels and asks for `[n]` markers. After rendering, Viora replaces each marker with a small favicon link and appends a source strip under the answer.

Favicons come from Chrome's own cache via the `favicon` permission (`/_favicon/?pageUrl=…`), so no third-party tracking pixel is requested for every source a user sees. When Chrome has no icon cached, the chip falls back to a monogram tile with a hue derived from the domain.

## How automation works

The model never touches the DOM. The content script builds a numbered list of visible interactive elements; the planner returns JSON; `parsePlan` drops anything that is not one of `click`, `fill`, `scroll`, `extract`, `done` and caps the run at five steps. Every element Viora acts on gets a short violet outline so nothing happens invisibly.

## Layout

```
manifest.json
src/
  background/service-worker.js   panel wiring, context menus
  content/content.js             page snapshot and action execution
  lib/
    providers.js                 streaming chat, image, search adapters
    storage.js                   settings and saved conversations
    markdown.js                  small escape-first renderer
    citations.js                 favicon chips and inline markers
    automation.js                plan validation and dispatch
    prompts.js                   one system prompt per mode
    dev-keys.js                  local testing keys (gitignored, not packed)
  sidepanel/                     the panel itself
  options/                       settings page
icons/
scripts/                         build and deploy
```

## Build and release

```bash
./scripts/build.sh          # writes dist/viora-extension-6.1.0.zip
./scripts/deploy.sh         # commits, tags, and pushes to GitHub
```

`deploy.sh` reads `GITHUB_REPO` from the environment or from `git remote origin`. Pushing a `v*` tag triggers `.github/workflows/release.yml`, which validates the manifest, builds the zip, and attaches it to a GitHub release.

## Known limits

- Chrome blocks content scripts on `chrome://` pages and the Web Store, so page context and automation are unavailable there.
- Maths is styled, not typeset. Adding KaTeX would mean bundling it, which this build deliberately avoids.
- The panel keeps the last 50 conversations locally and trims older ones.
- Free-tier reasoning models return their chain inside `<think>` tags rather than a separate field. Viora splits it back out, but a model that leaves the tag unclosed will show an empty answer until the stream finishes.

## Licence

MIT. See `LICENSE`.
